from django.shortcuts import render
import pickle
import os
import numpy as np

def predict_rating(request):
    # Load model and encoder
    model_path = os.path.join(os.path.dirname(__file__), 'rating_model.pkl')
    encoder_path = os.path.join(os.path.dirname(__file__), 'encoder1.pkl')

    with open(model_path, 'rb') as file:
        model = pickle.load(file)
    with open(encoder_path, 'rb') as file:
        encoder = pickle.load(file)

    if request.method == 'POST':
        director = request.POST.get('director')
        genre = request.POST.get('genre')
        
        # Prepare the input for prediction
        try:
            input_data = np.array([[director, genre]])
            input_encoded = encoder.transform(input_data)
        except ValueError as e:
            # This error happens if the category is unknown to the encoder
            return render(request, 'prediction_result.html', {
                'director': director, 
                'genre': genre, 
                'prediction': "Error: The director or genre is not recognized in the data."
            })

        # Predict
        prediction = model.predict(input_encoded)[0]
        prediction = 'High Rating' if prediction else 'Not High Rating'

        return render(request, 'prediction_result.html', {
            'director': director, 
            'genre': genre, 
            'prediction': prediction
        })

    return render(request, 'director_genre_form.html')
